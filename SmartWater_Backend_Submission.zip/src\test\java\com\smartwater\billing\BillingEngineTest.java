package com.smartwater.billing;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BillingEngineTest {

    @Mock private ApartmentRepo apartments;
    @Mock private HouseholdRepo households;
    @Mock private UsageRepo usage;
    @Mock private TariffPlanRepo tariffPlans;
    @Mock private BillingCycleRepo billingCycles;
    @Mock private WaterPurchaseRepo purchases;
    @Mock private InvoiceRepo invoices;
    @Mock private AlertRepo alerts;

    private AppService appService;

    @BeforeEach
    void setUp() {
        appService = new AppService(apartments, households, usage, tariffPlans, billingCycles, purchases, invoices, alerts);
    }

    @Test
    @DisplayName("Tiered Tariff Engine & Shared Allocation: calculates base, excess, and shared costs correctly")
    void testFinalizeCycleTieredAndSharedAllocation() {
        Apartment apt = new Apartment();
        apt.id = 1L;

        TariffPlan tp = new TariffPlan();
        tp.id = 10L;
        tp.apartment = apt;
        tp.baseThresholdKl = new BigDecimal("10.0");
        tp.baseRate = new BigDecimal("15.00");
        tp.excessRate = new BigDecimal("25.00");
        tp.overuseThresholdKl = new BigDecimal("20.0");

        BillingCycle cycle = new BillingCycle();
        cycle.id = 100L;
        cycle.apartment = apt;
        cycle.tariffPlan = tp;
        cycle.startsOn = LocalDate.of(2026, 1, 1);
        cycle.endsOn = LocalDate.of(2026, 1, 31);
        cycle.status = CycleStatus.OPEN;

        Household h1 = new Household();
        h1.id = 1001L;
        h1.apartment = apt;
        h1.flatNumber = "A-101";
        h1.flatSizeSqft = 1200;
        h1.hasMeter = true;

        Household h2 = new Household();
        h2.id = 1002L;
        h2.apartment = apt;
        h2.flatNumber = "A-102";
        h2.flatSizeSqft = 1200;
        h2.hasMeter = false;

        WaterPurchase purchase = new WaterPurchase();
        purchase.id = 500L;
        purchase.billingCycle = cycle;
        purchase.volumeKl = new BigDecimal("10.0");
        purchase.unitCost = new BigDecimal("20.00"); // Total procurement cost = 200.00

        WaterUsageLog log1 = new WaterUsageLog();
        log1.household = h1;
        log1.readingDate = LocalDate.of(2026, 1, 15);
        log1.meterReadingKl = new BigDecimal("14.0"); // 10 base @ 15 = 150, 4 excess @ 25 = 100 -> Total 250 base+excess

        when(billingCycles.findById(100L)).thenReturn(Optional.of(cycle));
        when(households.findByApartmentId(1L)).thenReturn(List.of(h1, h2));
        when(purchases.findByBillingCycleId(100L)).thenReturn(List.of(purchase));
        when(usage.findByHouseholdIdAndReadingDateBetween(eq(1001L), any(), any())).thenReturn(List.of(log1));
        when(invoices.save(any(Invoice.class))).thenAnswer(inv -> inv.getArgument(0));

        List<InvoiceView> generatedInvoices = appService.finalizeCycle(100L);

        assertEquals(2, generatedInvoices.size());

        InvoiceView invH1 = generatedInvoices.stream().filter(i -> i.householdId().equals(1001L)).findFirst().orElseThrow();
        assertEquals(new BigDecimal("14.0"), invH1.consumptionKl());
        assertEquals(new BigDecimal("150.00"), invH1.baseAmount());
        assertEquals(new BigDecimal("100.00"), invH1.excessAmount());
        assertEquals(new BigDecimal("200.00"), invH1.sharedAmount()); // Metered household gets shared procurement
        assertEquals(new BigDecimal("450.00"), invH1.totalAmount());

        InvoiceView invH2 = generatedInvoices.stream().filter(i -> i.householdId().equals(1002L)).findFirst().orElseThrow();
        assertEquals(BigDecimal.ZERO, invH2.consumptionKl());
        assertEquals(new BigDecimal("200.00"), invH2.sharedAmount()); // Fallback unmetered area distribution
        assertEquals(new BigDecimal("200.00"), invH2.totalAmount());

        assertEquals(CycleStatus.FINALIZED, cycle.status);
    }
}
